--Create the library instance
local AceLocale = LibStub:GetLibrary("AceLocale-3.0");

local L = AceLocale:NewLocale("BrokerPortals", "zhTW", false);

--Register translations
if L then

-- L["ANNOUNCE"] = "Announce cast of portals"
-- L["ANNOUNCEMENT"] = "Casting"
L["ATT_MINIMAP"] = "依附在小地圖"
L["HEARTHSTONE"] = "爐石"
L["INN"] = "旅店："
L["MIN"] = "分"
L["N/A"] = "無法使用"
L["OPTIONS"] = "選項"
L["P"] = "傳送門" -- Needs review
L["P_RUNE"] = "傳送門符文" -- Needs review
L["RCLICK"] = "右鍵點擊"
L["READY"] = "已就緒"
L["SEC"] = "秒"
L["SEE_SPELLS"] = "查看法術列表"
L["SHOW_ITEMS"] = "顯示物品" -- Needs review
L["SHOW_ITEM_COOLDOWNS"] = "顯示物品冷卻"
L["TP"] = "傳送" -- Needs review
L["TP_RUNE"] = "傳送符文" -- Needs review


end

